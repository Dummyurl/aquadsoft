<html>
<head></head>
<body>

<form action="<?php echo base_url('Webservice/Get_all_business');   ?>"  method="post" >

    <h1>Url is :  <?php echo base_url('Webservice/Get_all_business'); ?> </h1>
    This is get api
    <input type="submit" value="Result">

</form>


</body>
</html>